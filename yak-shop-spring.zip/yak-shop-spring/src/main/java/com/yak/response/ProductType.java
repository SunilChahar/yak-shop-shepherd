package com.yak.response;

public enum ProductType {

	MILK,WOOL
}
