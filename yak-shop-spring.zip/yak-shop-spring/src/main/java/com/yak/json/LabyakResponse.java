package com.yak.json;

public class LabyakResponse {

	private String name;
	
	private float age;
	
	private float age_last_shaved;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getAge() {
		return age;
	}

	public void setAge(float age) {
		this.age = age;
	}

	public float getAge_last_shaved() {
		return age_last_shaved;
	}

	public void setAge_last_shaved(float age_last_shaved) {
		this.age_last_shaved = age_last_shaved;
	}

}
