package com.yak.json.response;

public interface StockStatus {

}
