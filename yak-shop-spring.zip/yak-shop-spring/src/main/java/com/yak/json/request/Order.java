package com.yak.json.request;

public class Order {

	private float milk;
	
	private int skin;

	public float getMilk() {
		return milk;
	}

	public void setMilk(float milk) {
		this.milk = milk;
	}

	public int getSkin() {
		return skin;
	}

	public void setSkin(int skin) {
		this.skin = skin;
	}
	
}
